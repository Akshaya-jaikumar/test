
// Example interactivity for future use
console.log("Birthday surprise website loaded!");
